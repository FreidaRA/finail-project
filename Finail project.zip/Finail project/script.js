// add comments to descript what this script does
    const buttons = document.querySelectorAll("nav button");
    const pages = document.querySelectorAll(".page");

    buttons.forEach(button => {
      button.addEventListener("click", () => {
        const targetPage = button.dataset.page;

        // Update active button
        buttons.forEach(btn => btn.classList.remove("active"));
        button.classList.add("active");

        // Show the selected "page"
        pages.forEach(page => {
          page.classList.toggle("active", page.id === targetPage);
        });
      });
    });
function updateText(lang){
 allTxt=	 
	{
"English":{
	"block1Hdr":"Why we need to vote",
	"block1txt":"In the United States, we live in a Democracy. A Democracy is when the majority of citizens pick who they want to control their government. A Democracy fails its people if they do not vote however. Depending on how we vote, and who we vote for, will determine what policies are passed and what laws are enacted. Every single vote makes a difference. In smaller elections the difference in who wins and who does not win can be the difference of just one vote. In larger elections like the Presidential election, one vote can change who won the electoral votes for your state. If we want the government to work for the people, we must take voting seriously.",
	"block2hdr":"Democracies die unless we participate.", 
	"block2txt":"One vote can change the whole world!",
	"block3hdr1":"Steps before an election",
	"block3hdr2":"Make sure you are registered to vote",
	 "block3txt":"It is suggested to check with your local board of elections before the deadline to register or update your registration. It is very important that you make sure that your are registered and that your information is correct.",
	"blockquote":"Get involved in your local political parties to help get the best candidates elected to office.",
	"block4hdr":"POLLING PLACE LOCATOR",
	"block4txt":"It is very important to know where your polling place is! Find this out before election day and make a plan to go with friends who will hold you accountable. To locate your polling place, this tool will help you: https://www.vote.org/polling-place-locator/",
	"block5hdr":"Learn about the Candidates",
	"block5txt":"Before you go and vote, it is important to learn about the candidates who are on the ballot. You can google and find their campaign webpage, ask your local Democrat and Republican committee people, and find out when the League of Women Voters have their debates.",
	"block6hdr":"Voting by Mail or Absentee",
	"block6txt":"In each state there are different rules for voting outside of the polling places. Some alternatives allowed might be voting by mail, early voting, or absentee voting. To find out more about what is available in your state and the deadlines go to.https://www.vote.org/absentee-ballot/.",
	"block7hdr":"Know your Rights!",
	"block7txt":"The laws are constantly changing and unfortunately too many are trying to suppress our vote. It is important to know your rights so nobody can take away your vote! One thing people should know is if they are in line by the end of voting, do not get out of the line! You must be allowed to vote. To learn more about your rights go to https://www.whenweallvote.org/know-your-voting-rights/",
	"blocklang":"English",
	"blocka":"Links to register online",
	"blockb":"PA:", "blockc":"Other States:",
	"blockd":"Living internationally",
	"blockname":"Made by Freida Atkins, Girl Scout Silver Project,"},
		
	"Russian":{
		"block1Hdr":"Почему нам надо голосовать",
		"block1txt":"В Соединенных Штатах Америки мы живем в Демократии. При Демократии большинство граждан выбирают, кто будет в правительстве. Если люди не участвуют в выборах, Демократия терпит поражение. В зависимости от того как мы голосуем и за кого мы голосуем, будут зависеть законы и правила, которые принимаются. Каждый голос важен и значим. В выборах небольшого масштаба всего один голос может повлиять на результат. В выборах большого значения, таких как Президентских выборах, один голос может изменить за кого будут отданы электоральные голоса штата. Если мы хотим, чтобы правительство работало для людей, мы должны относиться к выборам серьезно",
		"block2hdr":" Демократия умирает без участия народа", 
		"block2txt":"  Один голос может изменить весь мир!",
		"block3hdr1":"Шаги до выборов","block3hdr2":"УБЕДИТЬ, ЧТО ТЫ ЗАРЕГИСТРИРОВАН НЫЙ ВЫБОРЩИК",
		"block3txt":"Рекомендуется проверить в вашем местном выборном совете статус вашей регистрации выборщика, и произвести необходимые изменения в статусе регистрации до истечения официальных сроков. https://www.vote.org/am-i-registered-to-vote/",
		"blockquote":"\"Присоединяйтесь к своим местным политическим партиям, чтобы помочь избрать на должность лучших кандидатов.\"",
		"block4hdr":"ЛОКАТОР ИЗБИРАТЕЛЬНОГО УЧАСТКА",
		"block4txt":"Крайне важно знать заранее, где находится ваш Избирательный Участок! Узнайте о точном месте вашего Избирательного Участка заранее, до дня выборов, и сделайте план для себя, возможно включите в ваш план пойти на выборы с друзьями. Эта ссылка поможет вам найти адрес вашего Избирательного Участка: https://www.vote.org/polling-place-locator/",
		"block5hdr":"ИЗУЧИТЕ ИНФОРМАЦИЮ О КАНДИДАТАХ",
		"block5txt":" Перед тем, как пойти голосовать, важно получить информацию о кандидатах, имена которых вы увидите в выборных бюллетенях. Вы можете найти в интернете сайты-страницы кампаний кандидатов, можете обратиться с вопросами к вашим местным представителям Демократический и Республиканской партий, и выяснить, когда Лига Женщин Выборщиков проводит публичные дебаты кандидатов.","block6hdr":"ГОЛОСОВАНИЕ ПО ПОЧТЕ ИЛИ ЗАОЧНО","block6txt":"В каждом штате есть свои правила о заочном голосовании. Возможен вариант голосования по почте, раннее голосование, или заочное голосование. Чтобы получить конкретную информацию вашего штата о правилах заочного голосования и сроках такого голосования, пользуйтесь ссылкой: https://www.vote.org/absentee-ballot/",
		"block7hdr":"ЗНАЙТЕ ВАШИ ПРАВА!","block7txt":"Законы постоянно меняются и, к сожалению, есть многочисленные попытки подавить участие граждан в выборах. Крайне важно знать ваши права для того, чтобы ваше права участвовать в выборах не было у вас отобрано! Одна важная деталь, которую надо знать и помнить - если вы встали в очередь для голосования на Избирательном Участке до окончание установленного времени голосования, не покидайте очередь! Вам должно быть предоставлено право проголосовать. Узнать больше о ваших правах выборщика вы можете здесь:https://www.whenweallvote.org/know-your-voting-rights/",
	
		"blocklang":"Russian",
		"blocka":"Ссылки для регистрации в интернете",
		"blockb":"Пенсильвания",
		"blockc":"Другие штаты",
		"blockd":"Граждане живущие за рубежом",
		"blockname":"Сделано Фрейдой Аткинс, Серебряный проект девочек-скаутов,"},
		
	"Japanese":{
		"block1Hdr":"投票することの大切さ",
		"block1txt":"アメリカ合衆国は、民主主義国家です。市民の多数が政権を執る人を選ぶ政府形態が民主主義です。でも、皆が投票をしなければ、民主主義は成り立ちません。どういう形で誰に投票するかで、どういった政策や法律が制定されるかが決まります。投票者の一票一票が私たちの暮らしを変える可能性を秘めています。より規模の小さい選挙では、たった一票が勝敗をわけることもあり、大統領選挙のようにより規模の大きい選挙では、たった一票が住んでいる州の選挙人投票の結果を左右するかもしれないのです。人民の意思を尊重し実行する政府が欲しいのなら、投票を真摯に受け止めなければなりません。",
		"block2hdr":"私たち⼀⼈ひとりが参 加しないと、⺠主主義 は滅びる",
		"block2txt":"  たった⼀票が世界を変 える！",
		"block3hdr1":"選挙にそなえ よう",
		"block3hdr2":" 選挙登録が完了してい ることを確認する",
		"block3txt":"選挙登録・登録内容の変更しめ切り⽇前に、居 住先の選挙登録委員会で登録の有無・登録内容 の確認をすることをおすすめします。選挙登録 が完了していること、そして登録内容に間違い がないことを確認することは重要です。 : https://www.vote.org/am-i-registered-to-vote/",
		"blockquote":"\"地元の政党に参加して、最 ⾼の候補者を選出するのを ⼿伝ってください。\"",
		"block4hdr":"投票所の場所を確認す る",
		"block4txt":"投票所がどこにあるかを事前に知ることは⾮常 に⼤切です。投票⽇の前に確認することを忘れ ないようにしましょう。投票⽇当⽇には、投票 することを忘れないように誰かと⼀緒に⾏く約 束をしておきましょう。投票所を⾒つけるに は、 https://www.vote.org/polling-place-locator/ が便利です。",
		"block5hdr":"候補者を知ろう",
		"block5txt":"投票する前にそれぞれの候補者について知るこ とは重要です。例えば、 Google 等の検索エン ジンを使って各候補者のホームページを読むこ と、居住先の⺠主党や共和党委員会の話を聞く こと、 the League of Women Voters （⼥性有権 者同盟）の討論会の⽇付を確認すること等があ げられます。",
		"block6hdr":"不在者投票または郵送 での投票","block6txt":"投票所以外のところで投票することに関する法 令は、州によって違います。州によっては、郵 送による投票、投票⽇前の⼀定期間⾏われる早 期投票、または不在者投票が⾏えます。居住先 の州で選択可能な投票⽅法とそれぞれの最終実 ⾏⽇を調べるには、https://www.vote.org/absentee-ballot/をご覧ください。","block7hdr":"⾃分の権利を知ろう",
		"block7txt":"選挙に関する法令は常に変化しています。残念なが ら、私たちが選挙権を実⾏することを抑圧しようとし ている⼈も多くいます。あなたの⼤切な⼀票が投票さ れ、確実に集計されるように、⾃分の権利を知ってお きましょう。特に知っておいてもらいたいのは、投票 ⽇当⽇の投票時間終了前に投票するための列に並んだ ら、投票するまで列を離れないようにすることです。 投票時間終了前に並んだ⼈には、投票権があります。 投票に関する権利に関しては、https://www.whenweallvote.org/know-yourvoting-rights/で詳しく説明されています。",
	
		"blocklang":"Japanese",
		"blocka":"選挙登録するためのリン ク集",
		"blockb":"ペンシルバニア州",
		"blockc":"その他の州（⽶国内）",
		"blockd":"⽶国外に住んでいる⽶国市⺠向け",
		"blockname":"ガールスカウトシルバープロジェクト、フレイダアトキンスによって作られました。" 
		},

    "Arabic":{
		"block1Hdr":"ﻟﻤﺎذا ﻧﺤﺘﺎج ﻟﻠﺘﺼﻮﻳﺖ",
		"block1txt":" ﻓﻲ اﻟﻮﻻﻳﺎت اﻟﻤﺘﺤﺪة ، ﻧﺤﻦ ﻧﻌﻴﺶ ﻓﻲ دوﻟﺔ دﻳﻤﻘﺮاﻃﻴﺔ. اﻟﺪﻳﻤﻘﺮاﻃﻴﺔ ﻫﻲ ﻋﻨﺪﻣﺎ ﻳﺨﺘﺎر ﻏﺎﻟﺒﻴﺔ اﻟﻤﻮاﻃﻨﻴﻦ ﻣﻦ ﻳﺮﻳﺪون اﻟﺴﻴﻄﺮة ﻋﲆ ﺣﻜﻮﻣﺘﻬﻢ. ﺗﺨﻴﺐ اﻟﺪﻳﻤﻘﺮاﻃﻴﺔ ﺷﻌﺒﻬﺎ إذا ﻟﻢ ﻳﺼﻮﺗﻮا. اﻋﺘﻤﺎدًا ﻋﲆ ﻛﻴﻔﻴﺔ ﺗﺼﻮﻳﺘﻨﺎ وﻣﻦ ﻧﺼﻮت ﻟﻪ ، ﺳﻨﺤﺪد اﻟﺴﻴﺎﺳﺎت اﻟﺘﻲ ﻳﺘﻢ ﺗﻤﺮﻳﺮﻫﺎ واﻟﻘﻮاﻧﻴﻦ اﻟﺘﻲ ﻳﺘﻢ ﺳﻨﻬﺎ. ﻛﻞ ﺻﻮت واﺣﺪ ﻳﺤﺪث ﻓﺮﻗﺎ. ﻓﻲ اﻻﻧﺘﺨﺎﺑﺎت اﻷﺻﻐﺮ ، ﻳﻤﻜﻦ أن ﻳﻜﻮن اﻻﺧﺘﻼف ﻓﻲ ﻣﻦ ﺳﻴﻔﻮز وﻣﻦ ﻻ ﻳﻔﻮز ﻓﺮق ﺻﻮت واﺣﺪ ﻓﻘﻂ. ﻓﻲ اﻻﻧﺘﺨﺎﺑﺎت اﻷﻛﺒﺮ ﻣﺜﻞ اﻻﻧﺘﺨﺎﺑﺎت اﻟﺮﺋﺎﺳﻴﺔ ، ﻳﻤﻜﻦ أن ﻳﻐﻴﺮ ﺻﻮت واﺣﺪ ﻣﻦ ﻓﺎز ﺑﺎﻷﺻﻮات اﻻﻧﺘﺨﺎﺑﻴﺔ ﻟﻮﻻﻳﺘﻚ. إذا أردﻧﺎ أن ﺗﻌﻤﻞ اﻟﺤﻜﻮﻣﺔ ﻣﻦ أﺟﻞ اﻟﺸﻌﺐ ، ﻳﺠﺐ أن ﻧﺄﺧﺬ اﻟﺘﺼﻮﻳﺖ ﻋﲆ ﻣﺤﻤﻞ اﻟﺠﺪ",
		"block2hdr":" Демократия умирает без участия народа.",
		"block2txt":"Один голос может изменить весь мир!",
		"block3hdr1":"ﺧﻄﻮات ﻣﺎ ﻗﺒﻞ اﻻﻧﺘﺨﺎﺑﺎت",
		"block3hdr2":"ﺗﺄﻛﺪ ﻣﻦ ﺗﺴﺠﻴﻠﻚ ﻟﻠﺘﺼﻮﻳﺖ",
		"block3txt":"ﻳُﻘﺘﺮح ﻣﺮاﺟﻌﺔ ﻣﺠﻠﺲ اﻻﻧﺘﺨﺎﺑﺎت اﻟﻤﺤﻠﻲ ﻗﺒﻞ اﻟﻤﻮﻋﺪ اﻟﻨﻬﺎﺋﻲ ﻟﻠﺘﺴﺠﻴﻞ أو ﺗﺤﺪﻳﺚ ﺗﺴﺠﻴﻠﻚ. ﻣﻦ اﻟﻤﻬﻢ ﺟﺪًا أن :ﺗﺘﺄﻛﺪ ﻣﻦ ﺗﺴﺠﻴﻠﻚ وأن ﻣﻌﻠﻮﻣﺎﺗﻚ ﺻﺤﻴﺤﺔ https://www.vote.org/am-i-registered-to-vote/",
		"blockquote":"\"ﺷﺎرك ﻓﻲ اﻷﺣﺰاب اﻟﺴﻴﺎﺳﻴﺔ اﻟﻤﺤﻠﻴﺔ ﻟﻠﻤﺴﺎﻋﺪة ﻓﻲ اﻧﺘﺨﺎب .أﻓﻀﻞ اﻟﻤﺮﺷﺤﻴﻦ ﻟﻤﻨﺼﺐ\"","block4hdr":"ﻣﺤﺪد ﻣﻜﺎن اﻻﻗﺘﺮاع","block4txt":"ﻣﻦاﻟﻤﻬﻢ ﺟﺪًا ﻣﻌﺮﻓﺔ ﻣﻜﺎن اﻻﻗﺘﺮاع! اﻛﺘﺸﻒ ذﻟﻚ ﻗﺒﻞ ﻳﻮم اﻻﻧﺘﺨﺎﺑﺎت وﺧﻄﻂ ﻟﻠﺬﻫﺎب ﻣﻊ اﻷﺻﺪﻗﺎء اﻟﺬﻳﻦ ﺳﻴُﺤﺎﺳﺒﻮﻧﻚ. ﻟﺘﺤﺪﻳﺪ ﻣﻜﺎن اﻻﻗﺘﺮاع ، ﺳﺘﺴﺎﻋﺪك ﻫﺬه اﻷداة ﻋﲆ:https://www.vote.org/polling-place ",
		"block5hdr":"ﺗﻌﺮف ﻋﲆ اﻟﻤﺮﺷﺤﻴﻦ","block5txt":"ﻗﺒﻞ أن ﺗﺬﻫﺐ ﻟﻠﺘﺼﻮﻳﺖ ، ﻣﻦ اﻟﻤﻬﻢ أن ﺗﻌﺮف اﻟﻤﺰﻳﺪ ﻋﻦ اﻟﻤﺮﺷﺤﻴﻦ اﻟﺬﻳﻦ ﻫﻢ ﻋﲆ ورﻗﺔ اﻻﻗﺘﺮاع. ﻳﻤﻜﻨﻚ اﻟﺒﺤﺚ واﻟﻌﺜﻮر ﻋﲆ ﺻﻔﺤﺔ اﻟﻮﻳﺐ اﻟﺨﺎﺻﺔ ﺑﺤﻤﻠﺘﻬﻢ google ﻓﻲ ، وﺳﺆال أﻋﻀﺎء اﻟﻠﺠﻨﺔ اﻟﻤﺤﻠﻴﺔ ﻟﻠﺪﻳﻤﻘﺮاﻃﻴﻴﻦ .واﻟﺠﻤﻬﻮرﻳﻴﻦ ، وﻣﻌﺮﻓﺔ ﻣﻮﻋﺪ ﻣﻨﺎﻗﺸﺎت راﺑﻄﺔ اﻟﻨﺎﺧﺒﺎت",
		"block6hdr":"اﻟﺘﺼﻮﻳﺖ ﻋﻦ ﻃﺮﻳﻖ اﻟﺒﺮﻳﺪ أو اﻟﻐﺎﺋﺐ",
		"block6txt":"ﺗﻮﺟﺪ ﻓﻲ ﻛﻞ وﻻﻳﺔ ﻗﻮاﻋﺪ ﻣﺨﺘﻠﻔﺔ ﻟﻠﺘﺼﻮﻳﺖ ﺧﺎرج أﻣﺎﻛﻦ اﻻﻗﺘﺮاع. ﻗﺪ ﺗﻜﻮن ﺑﻌﺾ اﻟﺒﺪاﺋﻞ اﻟﻤﺴﻤﻮح ﺑﻬﺎ ﻫﻲ اﻟﺘﺼﻮﻳﺖ ﺑﺎﻟﺒﺮﻳﺪ أو اﻟﺘﺼﻮﻳﺖ اﻟﻤﺒﻜﺮ أو اﻟﺘﺼﻮﻳﺖ اﻟﻐﻴﺎﺑﻲ. ﻟﻤﻌﺮﻓﺔ اﻟﻤﺰﻳﺪ ﺣﻮل ﻣﺎ ﻫﻮ ﻣﺘﺎح ﻓﻲ وﻻﻳﺘﻚ واﻟﻤﻮاﻋﻴﺪ اﻟﻨﻬﺎﺋﻴﺔ ، اﻧﺘﻘﻞ إل: https://www.vote.org/absentee-ballot/",
		"block7hdr":"!اﻋﺮف ﺣﻘﻮﻗﻚ",
		"block7txt":"اﻟﻘﻮاﻧﻴﻦ ﺗﺘﻐﻴﺮ ﺑﺎﺳﺘﻤﺮار وﻟﻸﺳﻒ ﻳﺤﺎول اﻟﻜﺜﻴﺮون ﻗﻤﻊ ﺗﺼﻮﻳﺘﻨﺎ. ﻣﻦ اﻟﻤﻬﻢ أن ﺗﻌﺮف ﺣﻘﻮﻗﻚ ﺣﺘﻰ ﻻ ﻳﺴﺘﻄﻴﻊ أﺣﺪ أن ﻳﺄﺧﺬ ﺻﻮﺗﻚ! ﺷﻲء واﺣﺪ ﻳﺠﺐ أن ﻳﻌﺮﻓﻪ اﻟﻨﺎس ﻫﻮ أﻧﻬﻢ إذا ﻛﺎﻧﻮا ﻓﻲ اﻟﻄﺎﺑﻮر ﺑﻨﻬﺎﻳﺔ اﻟﺘﺼﻮﻳﺖ ، ﻓﻼ ﺗﺨﺮج ﻋﻦ اﻟﺨﻂ! ﻳﺠﺐ أن ﻳﺴﻤﺢ ﻟﻚ ﺑﺎﻟﺘﺼﻮﻳﺖ. ﻟﻤﻌﺮﻓﺔ اﻟﻤﺰﻳﺪ ﻋﻦ ﺣﻘﻮﻗﻚ https://www.whenweallvote.org/know-your-voting-rights/ :اﻧﺘﻘﻞ إﱃ+++",
		
		"blocklang":"Arabic",
		"blocka":"رواﺑﻂ ﻟﻠﺘﺴﺠﻴﻞ ﻋﺒﺮ اﻹﻧﺘﺮﻧﺖ",
		"blockb":"اﻟﺴﻠﻄﺔ اﻟﻔﻠﺴﻄﻴﻨﻴﺔ",
		"blockc":"دول أﺧﺮى","blockd":"اﻟﻌﻴﺶ دوﻟﻴﺎ",
		"blockname":"، ﻣﻦ ﺻﻨﻊ ﻓﺮﻳﺪا أﺗﻜﻴﻨﺰ ، اﻟﻤﺸﺮوع اﻟﻔﻀﻲ ﻟﻔﺘﻴﺎت اﻟﻜﺸﺎﻓﺔ"},

    "Hungarian":{
		"block1Hdr":"Miért kell szavaznunk",
		"block1txt":"Az Egyesült Államokban demokráciában élünk. Demokrácia az, amikor a polgárok többsége kiválasztja azt az embert, akit akarják hogy a kormányát irányítja. Attól függően, hogy miként szavazunk, és ki számára, meghatározza hogy milyen politikákat és törvényeket fogadnak el. Minden szavazó személy fontos. Kisebb választásokon a különbség hogy ki nyer és ki nem, csak egy szavazat különbsége lehet. Nagyobb választásokon, például az elnökválasztáson, egy szavazat megváltoztathatja, ki nyerte meg a választási szavazatokat az államában. Ha azt akarjuk hogy a kormány az emberekért dolgozzon akkor komolyan kell vennünk a szavazást.",
		"block2hdr":"A demokráciák meghalnak, hacsak nem veszünk részt.",
		"block2txt":"Egy szavazat megváltoztathatja az egész világot!",
		"block3hdr1":"Szavazás előtt megteendő lépések",
		"block3hdr2":"Szavazás előtt megteendő lépések",
		"block3txt":"Javasoljuk, hogy a regisztráció vagy a regisztráció frissítésének határideje előtt forduljon a helyi választási tanácshoz. Nagyon fontos, hogy megbizonyosodjon arról, hogy regisztrálva van-e, és hogy az adatai helyesek.",
		"blockquote":"\"Csatlakozzon helyi politikai pártjaihoz, hogy a legjobb jelöltek hivatalba kerüljenek.\"",
		"block4hdr":"Tudjon meg többet a jelöltekről",
		"block4txt":"Mielőtt szavazni menne, fontos megismerni a szavazáson részt vevő jelölteket. Google-on kereshet és megkeresheti kampányuk weboldalát, megkérdezheti a helyi demokraták és republikánus bizottság embereit, és megtudhatja, hogy a Női Választók Ligája mikor ütemezte a vitákat.",
		"block5hdr":"Szavazás levélben vagy távollétben",
		"block5txt":"Minden államban a szavazóhelyiségen kívüli szavazáshoz különböző szabályok vonatkoznak. Néhány megengedett alternatíva lehet postai úton történő szavazás, előrehozott szavazás vagy távollétes szavazás. Ha többet szeretne megtudni arról, hogy mi áll rendelkezésre az Ön államában, és milyen határidőkre van szükség, látogasson el a https://www.vote.org/absentee-ballot/ weboldalra.",
		"block6hdr":"Szavazóhely-kereső",
		"block6txt":"Nagyon fontos tudni, hogy hol van a szavazóhelye! Ezt meg lehet találni a választási nap előtt, és tervet készíteni arra, hogy elmenjen olyan barátokkal, akik felelősségre vonják. A szavazóhely megtalálásához ez a weboldal segít https://www.vote.org/polling-place-locator/.",
		"block7hdr":"Ismerje meg a jogait!",
		"block7txt":"A törvények folyamatosan változnak és sajnos túl sokszor próbálják elnyomni a szavazatunkat. Fontos tudni a jogát, hogy senki ne vegye el a szavazatát! Egy dolgot az embereknek tudniuk kell: ha a szavazás végére sorban vannak, akkor ne lépjenek ki a sorból! Engedélyezni kell a szavazást. További információ a jogairól: https://www.whenweallvote.org/know-your-voting-rights/.",
		
		"blocklang":"Hungarian",
		"blocka":"Linkek az online regisztrációhoz",
		"blockb":"Pennsylvania",
		"blockc":"Egyéb államok",
		"blockd":"Nemzetközileg",
		"blockname":"Készítette: Freida Atkins, a cserkészlány ezüst projektje,"},
  
	"Yiddish":{
		"block1Hdr":"פאר וואס מען דאר",
		"block1txt":" אין דער פארייניקטע שטאטן לעבען מיר אין א דעמאקראטיע.  א דעמאקראטיע איז ווען די מערהייט פון די בירגער קלייבן אויס די מענשען וואס וועלען ריגירן די רעגירונג. אבער ווען די מענשן שטימען נישט וועט די דעמאקראטיע צעפאלן זיך.  געווענדט ווי אסוי מען שטימט און וואס פאר וועמען מען שטימט וועט פעסשטעלן וואס פאר א פראגראַמפונקט וועט ווערן   אנגענומען און וואס פאר א געזעץ וועט פאַראָרדענען. יעדער שטים מאַכט א חילוק.  אין קלענערער וואלע ן  איין שטים מאכען א חילוק ווער איז דער געווינער. אבער ווען מען שטימט פאר א פרעזידינט קען איי ןשטים מאכען א חילוק ווי אסוי די עלעקטאראלס פון די שטאַט וועלעען שטימען.  אויב מען וויל אז די רעגירונג זאל ארבעטן פאר דאס פאָלק, דארף מען נעמען דאס .שטים רעכט מיט ערנצט",
		"block2hdr":"ן פאר וואס מען דאר שטארבן ווען מענשען וועלען נישט אנטייל .נעמען",
		"block2txt":"איין שטים קען טוישען די גאנצע וועלט",
		"block3hdr1":"וואס מען דארף טוען פאר די וואלן",
		"block3hdr2":"מאכט זיכער דאס איהר זענט רעגיסטרירט צו שטימען",
		"block3txt":"עס איז סאַגדזשעסטיד צו קאָנטראָלירן דיין היגע וואַלן באָרד איידער די טערמין צו פאַרשרייַבן אָדער דערהייַנטיקן דיין רעגיסטראַציע און די אינפארמאציע וועגן אייך איז ריכטיק.  איהר זאלט נאכפרעגן ביי די קאלעגיע פון די וואלן וועגן די קאנדידאטן וואס זענען https://www.vote.org/am-iregistered-to-vote/  .אוף דעם שטימצעטל ",
		"blockquote":"\"באַקומען ינוואַלווד אין דיין היגע פּאָליטיש פּאַרטיעס צו באַקומען די בעסטער קאַנדאַדייץ עלעקטעד צו .אַמט\"",
		"block4hdr":"איהר קענט דאס געפונעןאין דעם שטים ארט",
		"block4txt":"עס איז זייער וויכטיג דאס איהר זאלט וויסען ווי אייער און דאס אויסגעפונען פאר דאם שטיםשטים ארט איז! טאג און פלאנעוועט צו גיין מיט חברים )פריינד( וואס .קענען זיכער מאכען דאס יעדער איז פאראנטווארלעך https://www.vote.org/polling-place-locator/",
		"block5hdr":"לערנען וועגן די קאַנדאַדייץ",
		"block5txt":"איהר קענען              און געפֿ ינען זייער וועבזייטל פון די קאַמפּ יין,איהר זאלט אויך נאכפרעגן די לאקאלי דעמאקראטישע אדער רעפובליקאנער קאמיטעט וועגן די קאנדידאטען, און איהר זאלט זיך באווסט מאכען ווען זייער דעבאטען וועלן זיין בא די ליגע פון .פרויעען וואלערס",
		"block6hdr":"פארפעלער שטימען אדער מיט די פאסט",
		"block6txt":"יעדער שטאט )מדינה( האט פארשידענע כללים וועגן וואלן איוסער די שטים ערטער.  איהר זאלט נאכזיכען וואס איז פאראן אין אייער שטאט:  צי איהר מעגט וואלן פריער אדער מיט די פאסט, אדער זיין א פארפעלער שטימער און ווען עס איז דער טערמין https://www.vote.org/absentee-ballot/",
		"block7hdr":"איהר זאל וויסן וואס אייער רעכט זענען",
		"block7txt":" געזעצן טוישען זיך קעסיידער אין ליידער איז דא א  סך מענשן וואס פרובירו צו פארשטיקן אונזכר רעכט צו שטימן.  עס איז זייער וויכטיג איהר זאלט וויסען אייער רעכט קעדיי קיינער זאל ניט אוועק נעמן אייער שטים.  איהר זאלט וויסען דאס ווי לאנג איהר זענט אין די ליניע דארפען זיי אייך לאזען שטימן, זיי קענען נישט פארמאכן די טיר פון דעם שטים ארט ביז דער לעצטער מענש שטימט. צו לערנען מער וועגן אייערע https://www.whenweallvote.org/know-your-voting-rights/:רעכט גייט צו",
		
		"blocklang":"Yiddish",
		"blocka":"לינקס צו פארשרייבץ אנליין",
		"blockb":"פענסילוועניע",
		"blockc":"אנדערע שטאטן",
		"blockd":"אס מען לעבט אין חוץ לארץ",
		"blockname":",,מיידל ויסקוקער זילבער פּ ראָ יעקט , ,Freida Atkins געמאכט דורך"
		},

    "Hebrew":{
		"block1Hdr":"למה אנחנו צריכים דמוקרט",
		"block1txt":"בארצות הברית אנו חיים בדמוקרטיה. דמוקרטיה היא כאשר רוב האזרחים בוחרים במי שהם רוצים לשלוט בממשלתם. דמוקרטיה נכשלת עם זה אם הם לא מצביעים. תלוי באופן בו אנו מצביעים ולמי אנו מצביעים, יקבע איזו מדיניות מועברת ואילו חוקים נחקקים. כל הצבעה בודדת עושה את ההבדל. בבחירות קטנות יותר ההבדל במי שמנצח ומי לא מנצח יכול להיות ההבדל של קול אחד בלבד. בבחירות גדולות יותר כמו הבחירות לנשיאות, קול אחד יכול לשנות את מי שזכה בקולות הבחירות למדינתך. אם אנו רוצים שהממשלה תפעל למען העם, עלינו .להתייחס להצבעה ברצינות",
		"block2hdr":"דמוקרטיות מתות אל אאם כן אנו משתתפים",
		"block2txt":"הצבעה אחת יכולה לשנות את כל העולם",
		"block3hdr1":"צעדים לפני בחירות",
		"block3hdr2":"וודע שאתה רשום להצב'ע",
		"block3txt":"תייעץ עם מועצת הבחירות המקומית שלך לפני המועד האחרון כדי להירשם או לעדכן את הרשמתך.חשוב :מאוד שתוודע שאתה רשום ושהמידע שלך נכון https://www.vote.org/am-i-registered-to-vote/",
		"blockquote":"\"התערב במפלגות הפוליטיות המקומיות שלך כדי שיבחרו את המועמדים הטובים ביותר .לתפקיד\"",
		"block4hdr":"איתור מקום הקלפי",
		"block4txt":"חשוב מאוד לדעת היכן נמצא מקום הקלפי שלך גלה זאת לפני יום הבחירות וקבע תוכנית ללכת עם חברים שייקבעו לך אחריותכדי לאתר את מקום הקלפי שלך, :כלי זה יעזור לך https://www.vote.org/polling-place-locator/",
		"block5hdr":" לפני שאתה הולך להצביע, חשוב ללמוד על המועמדים שנמצאים .בקלפי",
		"block5txt":"אתה יכול לחפש בגוגל ולמצוא את דף הקמפיין שלהםאתה יכול גם לשאול את אנשי הוועדה הדמוקרטים והרפובליקנים המקומיים שלך,ולגלות מתי הליגה של נשים הבוחרות מנהלת את הוויכוחים .שלהם",
		"block6hdr":"הצבעה בדואר או נפקד",
		"block6txt":"בכל מדינה ישנם כללים שונים להצבעה מחוץ למקומות הקלפיחלק מהחלופות המותרות עשויות להיות הצבעה בדואר, הצבעה מוקדמת או הצבעה נעדרת. למידע נוסף על הזמינות במדינתך והמועדים הבאיםhttps://www.vote.org/absentee-ballot/",
		"block7hdr":"!דע את זכויותיך",
		"block7txt":"החוקים משתנים כל הזמן ולמרבה הצער רבים מדי מנסים לדכא את הצבעתנו.חשוב להכיר את זכויותיך כדי שאף אחד לא יוכל להוריד את הצבעתך!דבר אחד אנשים צריכים לדעת שהוא אם הם נמצאים בתור עד סוף ההצבעה, אל תצא מהקו!אתה חייב להיות רשאי :להצביע. למידע נוסף על זכויותיך היכנס לאתר זה https://www.whenweallvote.org/know-your-voting-rights/",
		
		"blocklang":"Hebrew",
		"blocka":"קישורים להרשמה באינטרנט",
		"blockb":"פנסילבניה",
		"blockc":"מדינות אחרות",
		"blockd":"ח''ם חוץ מארצות הבר'ת",
		"blockname":",תוצרת פרידה אטקינס, פרויקט הכסף של הצופים"},

    "Dutch":{
		"block1Hdr":"Waarom we moeten stemmen",
		"block1txt":"In de Verenigde Staten leven we in een democratie. Een land is democratisch wanneer de meerderheid van de bewoners kiezen wie in de regering zit. Echter, een democratie faalt haar bevolking als mensen niet stemmen. Wat voor beleid wordt gekozen, en hoe wetten worden uitgevoerd, hangt af van hoe we stemmen en voor wie we stemmen. Ieder stem maakt een verschil. In kleinere verkiezingen kan het verschil tussen wie wint en wie verliest bepaalt worden door een stem. In grotere verkiezingen, zoals voor President, kan een stem veranderen wie de electorale stemmen voor uw staat wint. Als we willen dat de regering voor de mensen werkt, dan moeten we stemmen serieus nemen",
		"block2hdr":"Democratie sterft tenzij we er deel aan nemen.",
		"block2txt":"Een stem kan de wereld veranderen!","block3hdr1":"Stappen die u kunt nemen voor een verkiezing.",
		"block3hdr2":"Zorg dat u geregistreerd bent om te stemmen.",
		"block3txt":"Het is erg belangrijk dat u verifieert dat u geregistreerd bent en dat de informatie correct is. U kunt dit bij de verkiezingsraad (the local board of elections) doen voordat de registratiedatum is verlopen.",
		"blockquote":"\"Doe mee met uw lokale politieke partijen om de beste kandidaten voor hun functie te krijgen.\"",
		"block4hdr":"Leer over de kandidaten",
		"block4txt":"Voordat u gaat stemmen, is het belangrijk dat u zich informeerd over de kandidaten die op de lijst staan. U kunt hun campagne webpagina googelen, informeren bij de lokale Democratic of Republican Committee, of nagaan wanneer de League of Women Voters hun debatten hebben.",
		"block5hdr":"Stemmen via de post of “Absentee”",
		"block5txt":"Ieder staat heeft haar eigen regels voor het stemmen indien u niet zelf naar een stembureau kunt gaan. Sommige alternatieven die zijn toegestaan zijn stemmen per post, vroeg stemmen, of als “Absentee” stemmen. Om meer te weten te komen over wat mogelijk is in uw staat, en wanneer de uiterste datum is dat u die mogelijkheid kunt gebruiken, ga naar:https://www.vote.org/absentee-ballot/",
		"block6hdr":" Polling Place locator",
		"block6txt":"Het is erg belangrijk om te weten waar uw stembureau is. Zoek dit van tevoren uit en maak een plan om samen met vrienden te gaan stemmen zodat u zich aan elkaar verplicht voelt. U kunt deze link gebruiken om de locatie van uw stembureau te vinden.https://www.vote.org/polling-place-locator/",
		"block7hdr":"Weet wat uw rechten zijn!",
		"block7txt":"De wetten veranderen constant en helaas zijn er vele die proberen om het stemmen te onderdrukken. Het is belangrijk om uw rechten te weten zodat niemand uw stem kan wegnemen. Als u tegen sluitingstijd nog in de rij staat, zorg dat u de rij niet verlaat! Het zou kunnen dat u dan niet meer kunt stemmen. Om meer te weten te komen over uw stemrecht ga naar:https://www.whenweallvote.org/know-your-voting-rights",	
		
		"blocklang":"Dutch",
		"blocka":"Links om online te registreren.",
		"blockb":"PA (Pennsylvania):",
		"blockc":"Andere staten:",
		"blockd":"Als je buiten de Verenigde Staten woont:",
		"blockname":"Gemaakt door Freida Atkins, Girl Scout Silver Project,"}
	};
	console.log(allTxt);
 const selectedLang = allTxt[lang];
  console.log(selectedLang);
  console.log(selectedLang['block1Hdr']);
 /* document.getElementById('block1Hdr').textContent =selectedLang['block1Hdr'];
  document.getElementById('block1txt').textContent =selectedLang['block1txt'];
  document.getElementById('block2Hdr').textContent =selectedLang['block2Hdr'];
  document.getElementById('block2txt').textContent =selectedLang['block2txt'];
  document.getElementById('block3Hdr1').textContent =selectedLang['block1Hdr'];
  document.getElementById('block3Hdr2').textContent =selectedLang['block1Hdr'];
  document.getElementById('block3txt').textContent =selectedLang['block1Hdr'];
  document.getElementById('blockquote').textContent =selectedLang['blockquote'];
  document.getElementById('block1Hdr').textContent =selectedLang['block1Hdr'];
  document.getElementById('block1Hdr').textContent =selectedLang['block1Hdr'];
  document.getElementById('block1Hdr').textContent =selectedLang['block1Hdr'];
  document.getElementById('block1Hdr').textContent =selectedLang['block1Hdr'];
  document.getElementById('block1Hdr').textContent =selectedLang['block1Hdr'];
  document.getElementById('block1Hdr').textContent =selectedLang['block1Hdr'];
*/

for (const [key, value] of Object.entries(selectedLang)) {
console.log(`Key: ${key}, Value: ${value}`);
document.getElementById(key).textContent = value;
}
 


}
 updateText('English');
